import { useState, useEffect, useCallback } from 'react';
import { INITIAL_ENTRIES } from './lib/initialEntries';
import { initGoogleAuth, requestToken, fetchGmailLeads, todayStr, daysUntil, fmtDate } from './lib/gmail';
import './App.css';

const STORAGE_KEY = 'snc_tracker_v10';
const PENDING_KEY = 'snc_pending_gmail';
const CLIENT_ID = process.env.REACT_APP_GOOGLE_CLIENT_ID;

const CATEGORIES = ['Leads & Quotations', 'BNI Referrals', 'Suppliers & Procurement', 'Indiamart Leads', 'Internal / Admin'];
const STATUSES = ['Active', 'Overdue', 'Closed', 'Dead'];

const CAT = {
  'Leads & Quotations':      { bg: '#1A1535', text: '#7B72E9', accent: '#7B72E9', icon: '◆' },
  'BNI Referrals':           { bg: '#1E1608', text: '#E8A83A', accent: '#E8A83A', icon: '⬡' },
  'Suppliers & Procurement': { bg: '#0A1A12', text: '#3DBF8A', accent: '#3DBF8A', icon: '▲' },
  'Indiamart Leads':         { bg: '#1A0E05', text: '#F07030', accent: '#F07030', icon: '●' },
  'Internal / Admin':        { bg: '#150A1E', text: '#9B59B6', accent: '#9B59B6', icon: '◉' },
};
const STATUS = {
  'Active':  { dot: '#5B8FE8', border: '#5B8FE8' },
  'Overdue': { dot: '#E57373', border: '#E57373' },
  'Closed':  { dot: '#5DBF8A', border: '#5DBF8A' },
  'Dead':    { dot: '#444',    border: '#333' },
};

function loadSaved() {
  try {
    const s = localStorage.getItem(STORAGE_KEY);
    if (s) { const p = JSON.parse(s); if (Array.isArray(p) && p.length) return p; }
  } catch {}
  return INITIAL_ENTRIES.map(e => ({
    ...e,
    status: e.status === 'Active' && e.followUpDate && daysUntil(e.followUpDate) < 0 ? 'Overdue' : e.status
  }));
}

function loadPending() {
  try { const s = localStorage.getItem(PENDING_KEY); if (s) return JSON.parse(s); } catch {}
  return [];
}

const EMPTY = { name: '', company: '', category: CATEGORIES[0], lastContact: todayStr(), followUpDate: todayStr(), notes: '', status: 'Active', source: 'Manual' };

export default function App() {
  const [entries, setEntries] = useState(loadSaved);
  const [pending, setPending] = useState(loadPending); // Gmail entries awaiting approval
  const [tab, setTab] = useState('All');
  const [statusF, setStatusF] = useState('All');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('followUpDate');
  const [expanded, setExpanded] = useState(null);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editId, setEditId] = useState(null);
  const [toast, setToast] = useState(null);
  const [view, setView] = useState('tracker'); // 'tracker' | 'inbox'
  const [syncing, setSyncing] = useState(false);
  const [googleClient, setGoogleClient] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Persist entries
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(entries)); } catch {}
  }, [entries]);

  useEffect(() => {
    try { localStorage.setItem(PENDING_KEY, JSON.stringify(pending)); } catch {}
  }, [pending]);

  // Init Google OAuth
  useEffect(() => {
    if (!CLIENT_ID || !window.google) return;
    const interval = setInterval(() => {
      if (window.google?.accounts?.oauth2) {
        clearInterval(interval);
        try {
          const client = window.google.accounts.oauth2.initTokenClient({
            client_id: CLIENT_ID,
            scope: 'https://www.googleapis.com/auth/gmail.readonly',
            callback: () => {},
          });
          setGoogleClient(client);
        } catch {}
      }
    }, 500);
    return () => clearInterval(interval);
  }, []);

  function showToast(msg, type = 'default') {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  }

  // Gmail sync
  const syncGmail = useCallback(async () => {
    if (!googleClient) { showToast('Google not configured.', 'warn'); return; }
    setSyncing(true);
    try {
      const token = await requestToken(googleClient);
      setIsLoggedIn(true);
      const leads = await fetchGmailLeads(token);

      // Filter out already-seen gmail IDs
      const existingIds = new Set([
        ...entries.map(e => e.gmailId).filter(Boolean),
        ...pending.map(e => e.gmailId).filter(Boolean),
      ]);
      const newLeads = leads.filter(l => !existingIds.has(l.gmailId));

      if (newLeads.length === 0) {
        showToast('No new emails found.', 'default');
      } else {
        const withIds = newLeads.map((l, i) => ({ ...l, id: Date.now() + i }));
        setPending(prev => [...prev, ...withIds]);
        setView('inbox');
        showToast(`${newLeads.length} new email(s) in inbox — review to add.`, 'success');
      }
    } catch (err) {
      showToast('Gmail sync failed. Check permissions.', 'warn');
    }
    setSyncing(false);
  }, [googleClient, entries, pending]);

  // Approve pending Gmail entry → add to tracker
  function approvePending(item) {
    setEntries(prev => [...prev, { ...item, id: Date.now() }]);
    setPending(prev => prev.filter(p => p.id !== item.id));
    showToast('Added to tracker.', 'success');
  }
  function rejectPending(id) {
    setPending(prev => prev.filter(p => p.id !== id));
    showToast('Dismissed.', 'warn');
  }
  function approveAll() {
    const withIds = pending.map((p, i) => ({ ...p, id: Date.now() + i }));
    setEntries(prev => [...prev, ...withIds]);
    setPending([]);
    showToast(`${withIds.length} entries added.`, 'success');
    setView('tracker');
  }

  // Entry actions
  function saveEntry() {
    if (!form.name || !form.followUpDate) return;
    if (editId !== null) {
      setEntries(prev => prev.map(e => e.id === editId ? { ...form, id: editId } : e));
      showToast('Entry updated.', 'success');
    } else {
      setEntries(prev => [...prev, { ...form, id: Date.now() }]);
      showToast('Entry added.', 'success');
    }
    setModal(false); setEditId(null); setForm(EMPTY);
  }
  function deleteEntry(id) { setEntries(prev => prev.filter(e => e.id !== id)); showToast('Removed.', 'warn'); }
  function changeStatus(id, status) { setEntries(prev => prev.map(e => e.id === id ? { ...e, status } : e)); }
  function openEdit(e) { setForm({ ...e }); setEditId(e.id); setModal(true); }

  // Filtered + sorted entries
  const filtered = entries.filter(e => {
    if (tab !== 'All' && e.category !== tab) return false;
    if (statusF !== 'All' && e.status !== statusF) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!e.name.toLowerCase().includes(q) && !e.company.toLowerCase().includes(q) && !e.notes.toLowerCase().includes(q)) return false;
    }
    return true;
  }).sort((a, b) => {
    if (sort === 'followUpDate') return new Date(a.followUpDate) - new Date(b.followUpDate);
    if (sort === 'name') return a.name.localeCompare(b.name);
    if (sort === 'status') return a.status.localeCompare(b.status);
    return 0;
  });

  const stats = {
    overdue: entries.filter(e => e.status === 'Overdue').length,
    today: entries.filter(e => e.followUpDate === todayStr() && e.status === 'Active').length,
    active: entries.filter(e => e.status === 'Active').length,
    closed: entries.filter(e => e.status === 'Closed').length,
  };

  const tabCounts = {};
  CATEGORIES.forEach(c => { tabCounts[c] = entries.filter(e => e.category === c).length; });

  return (
    <div className="app">
      {/* Toast */}
      {toast && <div className={`toast toast-${toast.type}`}>{toast.msg}</div>}

      {/* Header */}
      <header className="header">
        <div className="header-left">
          <div className="header-sub">SATYANARAYAN &amp; CO. · 11 CLIVE ROW, KOLKATA</div>
          <div className="header-title"><span className="accent">◈</span> Follow-Up Tracker</div>
        </div>
        <div className="header-right">
          {pending.length > 0 && (
            <button className="btn-inbox" onClick={() => setView(view === 'inbox' ? 'tracker' : 'inbox')}>
              📥 Inbox <span className="badge-count">{pending.length}</span>
            </button>
          )}
          <button
            className={`btn-sync ${syncing ? 'syncing' : ''} ${isLoggedIn ? 'connected' : ''}`}
            onClick={syncGmail}
            disabled={syncing}
          >
            {syncing ? '⟳ Syncing...' : isLoggedIn ? '✓ Sync Gmail' : '⟳ Connect Gmail'}
          </button>
          <button className="btn-new" onClick={() => { setModal(true); setEditId(null); setForm(EMPTY); }}>+ NEW</button>
        </div>
      </header>

      {/* Stats */}
      <div className="stats">
        {[
          { label: 'OVERDUE', val: stats.overdue, color: '#E57373', bg: '#1A0808' },
          { label: 'DUE TODAY', val: stats.today, color: '#E8A83A', bg: '#1A1208' },
          { label: 'ACTIVE', val: stats.active, color: '#5B8FE8', bg: '#081220' },
          { label: 'CLOSED', val: stats.closed, color: '#5DBF8A', bg: '#081510' },
        ].map((s, i) => (
          <div key={s.label} className="stat-cell" style={{ background: s.bg, borderRight: i < 3 ? '1px solid #1E1E1E' : 'none' }}>
            <div className="stat-val" style={{ color: s.color }}>{s.val}</div>
            <div className="stat-lbl" style={{ color: s.color }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Gmail Inbox View */}
      {view === 'inbox' && (
        <div className="inbox-panel">
          <div className="inbox-header">
            <div className="inbox-title">📥 Gmail Inbox — {pending.length} pending review</div>
            <div className="inbox-actions">
              {pending.length > 0 && <button className="btn-approve-all" onClick={approveAll}>Add All ({pending.length})</button>}
              <button className="btn-back" onClick={() => setView('tracker')}>← Back to Tracker</button>
            </div>
          </div>
          {pending.length === 0 ? (
            <div className="inbox-empty">No pending emails. Sync Gmail to check for new leads.</div>
          ) : pending.map(item => (
            <div key={item.id} className="inbox-card">
              <div className="inbox-card-body">
                <div className="inbox-name">{item.name}</div>
                <div className="inbox-company">{item.company}</div>
                <div className="inbox-notes">{item.notes}</div>
                <div className="inbox-meta">
                  <span className="cat-badge" style={{ background: CAT[item.category]?.bg, color: CAT[item.category]?.accent }}>
                    {CAT[item.category]?.icon} {item.category}
                  </span>
                  <span style={{ color: '#555', fontSize: '10px' }}>{fmtDate(item.lastContact)}</span>
                </div>
              </div>
              <div className="inbox-card-actions">
                <button className="btn-approve" onClick={() => approvePending(item)}>✓ Add</button>
                <button className="btn-reject" onClick={() => rejectPending(item.id)}>✕</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tracker View */}
      {view === 'tracker' && (
        <>
          {/* Tabs */}
          <div className="tabs">
            {['All', ...CATEGORIES].map(cat => {
              const count = cat === 'All' ? entries.length : tabCounts[cat];
              const active = tab === cat;
              const c = CAT[cat] || {};
              return (
                <button key={cat} className={`tab ${active ? 'tab-active' : ''}`}
                  style={{ borderBottomColor: active ? (c.accent || '#C8B99A') : 'transparent', color: active ? (c.accent || '#C8B99A') : '#555' }}
                  onClick={() => setTab(cat)}>
                  {cat !== 'All' && <span style={{ opacity: 0.7 }}>{c.icon}</span>}
                  {cat}
                  <span className="tab-count" style={active ? { background: c.bg, color: c.accent, borderColor: c.accent + '44' } : {}}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Filters */}
          <div className="filters">
            <input className="filter-input" placeholder="Search name, company, notes..." value={search} onChange={e => setSearch(e.target.value)} />
            <select className="filter-select" value={statusF} onChange={e => setStatusF(e.target.value)}>
              <option value="All">All Statuses</option>
              {STATUSES.map(s => <option key={s}>{s}</option>)}
            </select>
            <select className="filter-select" value={sort} onChange={e => setSort(e.target.value)}>
              <option value="followUpDate">Sort: Follow-up Date</option>
              <option value="name">Sort: Name</option>
              <option value="status">Sort: Status</option>
            </select>
          </div>

          {/* Entries */}
          <div className="entries">
            {filtered.length === 0 ? (
              <div className="empty-msg">NO ENTRIES MATCH YOUR FILTER</div>
            ) : filtered.map(entry => {
              const days = entry.followUpDate ? daysUntil(entry.followUpDate) : null;
              const cs = CAT[entry.category] || {};
              const ss = STATUS[entry.status] || STATUS['Active'];
              const isUrgent = entry.status === 'Overdue' || days === 0;
              const isExp = expanded === entry.id;
              let dayStr = '', dayClass = '';
              if (days !== null) {
                if (days < 0) { dayStr = `⚠ ${Math.abs(days)}D OVERDUE`; dayClass = 'overdue'; }
                else if (days === 0) { dayStr = '⚡ TODAY'; dayClass = 'today'; }
                else { dayStr = `${fmtDate(entry.followUpDate)} · ${days}D`; dayClass = 'upcoming'; }
              }
              return (
                <div key={entry.id} className={`entry-card ${isUrgent ? 'urgent' : ''} ${entry.status === 'Closed' ? 'closed' : ''} ${entry.status === 'Dead' ? 'dead' : ''}`}
                  style={{ borderLeftColor: ss.border }}>
                  <div className="entry-main" onClick={() => setExpanded(isExp ? null : entry.id)}>
                    <div className="entry-body">
                      <div className="entry-name-row">
                        <span className="entry-name">{entry.name}</span>
                        {entry.source === 'Email' && <span className="source-badge email">📧 GMAIL</span>}
                        {entry.source === 'Indiamart' && <span className="source-badge indiamart">🟠 INDIAMART</span>}
                        <span className="cat-badge" style={{ background: cs.bg, color: cs.accent, borderColor: cs.accent ? cs.accent + '33' : '#222' }}>
                          {cs.icon} {entry.category.toUpperCase()}
                        </span>
                      </div>
                      {entry.company && <div className="entry-company">{entry.company}</div>}
                      {isExp
                        ? <div className="entry-notes-full">{entry.notes}</div>
                        : <div className="entry-notes-preview">{entry.notes.slice(0, 70)}{entry.notes.length > 70 ? '…' : ''}</div>
                      }
                      <div className="entry-meta">
                        <span>LAST: <span className="meta-val">{fmtDate(entry.lastContact)}</span></span>
                        <span>FOLLOW-UP: <span className={`meta-val meta-${dayClass}`}>{dayStr}</span></span>
                      </div>
                    </div>
                    <div className="entry-actions" onClick={e => e.stopPropagation()}>
                      <span className="status-badge" style={{ color: ss.dot, borderColor: ss.dot + '33' }}>
                        <span className="status-dot" style={{ background: ss.dot }}></span>
                        {entry.status.toUpperCase()}
                      </span>
                      <div className="action-row">
                        <select className="action-select" value={entry.status} onChange={e => changeStatus(entry.id, e.target.value)}>
                          {STATUSES.map(s => <option key={s}>{s}</option>)}
                        </select>
                        <button className="btn-edit" onClick={() => openEdit(entry)}>EDIT</button>
                        <button className="btn-del" onClick={() => deleteEntry(entry.id)}>✕</button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* Modal */}
      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-title"><span className="accent">{editId ? '◈' : '+'}</span> {editId ? 'EDIT ENTRY' : 'NEW FOLLOW-UP'}</div>
            <div className="form-group"><label className="form-label">Name *</label>
              <input className="form-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="form-group"><label className="form-label">Company</label>
              <input className="form-input" value={form.company} onChange={e => setForm(f => ({ ...f, company: e.target.value }))} />
            </div>
            <div className="form-group"><label className="form-label">Category</label>
              <select className="form-input" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-row">
              <div className="form-group"><label className="form-label">Last Contact</label>
                <input className="form-input" type="date" value={form.lastContact} onChange={e => setForm(f => ({ ...f, lastContact: e.target.value }))} />
              </div>
              <div className="form-group"><label className="form-label">Follow-Up Date *</label>
                <input className="form-input" type="date" value={form.followUpDate} onChange={e => setForm(f => ({ ...f, followUpDate: e.target.value }))} />
              </div>
            </div>
            <div className="form-group"><label className="form-label">Source</label>
              <select className="form-input" value={form.source} onChange={e => setForm(f => ({ ...f, source: e.target.value }))}>
                {['Manual', 'Email', 'Indiamart', 'BNI', 'Direct Call', 'WhatsApp'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group"><label className="form-label">Notes</label>
              <textarea className="form-input form-textarea" rows={4} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
            <div className="form-group"><label className="form-label">Status</label>
              <select className="form-input" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="modal-btns">
              <button className="btn-save" onClick={saveEntry}>{editId ? 'SAVE CHANGES' : 'ADD ENTRY'}</button>
              <button className="btn-cancel" onClick={() => { setModal(false); setEditId(null); setForm(EMPTY); }}>CANCEL</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

# SNC Follow-Up Tracker — Setup Guide

## What this is
A web-based CRM tracker for Satyanarayan & Co. with Gmail sync.
- 242 existing entries preloaded
- Gmail sync pulls emails with steel/pipe keywords + quotation replies
- Approval inbox — review Gmail leads before adding to tracker
- Works on laptop and mobile browser
- Data saves to browser localStorage

---

## STEP 1 — Create GitHub Account
1. Go to https://github.com and click **Sign up**
2. Use your business email
3. Verify email and complete setup

---

## STEP 2 — Upload this code to GitHub
1. On GitHub, click **+** → **New repository**
2. Name it: `snc-tracker`
3. Set to **Public**, click **Create repository**
4. On the next screen, click **uploading an existing file**
5. Upload ALL the files from this folder maintaining the folder structure:
   - `package.json`
   - `vercel.json`
   - `public/index.html`
   - `src/index.js`
   - `src/App.js`
   - `src/App.css`
   - `src/lib/initialEntries.js`
   - `src/lib/gmail.js`
6. Click **Commit changes**

---

## STEP 3 — Get Google Client ID (Gmail API)
1. Go to https://console.cloud.google.com
2. Click **Select a project** → **New Project**
3. Name: `SNC Tracker` → **Create**
4. Left menu → **APIs & Services** → **Library**
5. Search **Gmail API** → Click it → **Enable**
6. Left menu → **APIs & Services** → **Credentials**
7. Click **+ Create Credentials** → **OAuth client ID**
8. If prompted, click **Configure Consent Screen**:
   - Choose **External** → **Create**
   - App name: `SNC Tracker`
   - Support email: your business Gmail
   - Click **Save and Continue** through all steps
9. Back at Credentials → **Create OAuth client ID**:
   - Application type: **Web application**
   - Name: `SNC Tracker`
   - **Authorized JavaScript origins**: leave blank for now (you'll add after Vercel deploy)
   - Click **Create**
10. Copy the **Client ID** (looks like: `123456789-abc.apps.googleusercontent.com`)

---

## STEP 4 — Deploy on Vercel
1. Go to https://vercel.com → **Sign up with GitHub**
2. Click **Add New Project**
3. Import your `snc-tracker` repository
4. Before clicking Deploy, click **Environment Variables**:
   - Key: `REACT_APP_GOOGLE_CLIENT_ID`
   - Value: paste your Client ID from Step 3
5. Click **Deploy** — wait ~2 minutes
6. Copy your live URL (like `snc-tracker.vercel.app`)

---

## STEP 5 — Add your Vercel URL to Google
1. Go back to https://console.cloud.google.com
2. **APIs & Services** → **Credentials** → click your OAuth client
3. Under **Authorized JavaScript origins**, click **+ Add URI**
4. Add: `https://snc-tracker.vercel.app` (your actual URL)
5. Click **Save**

---

## DONE — Open your tracker
- Go to your Vercel URL on any browser
- Click **Connect Gmail** → sign in with your business Gmail
- New email leads appear in the **Inbox** tab for review
- Approve the ones you want added to the tracker

---

## Daily use
- Open the URL on laptop or phone
- Click **Sync Gmail** to pull new emails
- Review inbox → approve leads
- Add manual entries with **+ NEW**
- Mark done entries as **Closed**

---

## If you want to add new entries via Claude
Just tell Claude the names as always — Claude will update the `initialEntries.js` file,
you re-upload to GitHub, and Vercel auto-deploys in ~1 minute.
